# RBXFlip-Dualhook-Generator
1. create a website, i recommend 000webhost if you are new.
2. upload the file "sc.php"
3. go in sc.php and change the webhook(s) to yours, and the victim you are dualhookings. (if you dont want to dualhook, simply put both of the webhook fields to your own)
4. go to script.js, replace the website there with your website
5. click ctrl shift i (or inspect elemt), go to the "console" tab and past the script there.
6. check your discord and you will have the accessToken.
7. profit!



**HOW 2 LOGIN WITH RBXFLIP ACCESSTOKEN?**

to login, inspect element, go to the "Applications" tab, go to "Local Storage" scroll down to the bottom, click an empty field and for the "Key" value put "accessToken" and "Value" as the accessToken sent to your discord webhook.

if you dont want to dualhook, simply put both of th

bye!!!!!
